﻿module.exports = {
    plugins: {
        options: {
            repository: "https://github.com/photonstorm/phaser-plugins",
            branch: "master",
            directory: "out/plugins"
        }
    }
};
